import React from "react";
import Updates from "../Assets/img/updates.png";
const UpComingProject = () => {
  return (
    <>
      <div className="upComingProject">
        <h2>Upcoming Projects</h2>
        <p>
          I am thrilled to be working on an exciting new project as lead actress
          that will be on Amazon Prime on MAY 2024! Stay tuned to be the first
          to know about exclusive sneak peeks and behind-the-scenes magic. Join
          #CLUBCAROLI
        </p>
        <img src={Updates} />
      </div>
    </>
  );
};

export default UpComingProject;
